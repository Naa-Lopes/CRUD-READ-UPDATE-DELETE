<!DOCTYPE html>
<html lang="pt">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Produto</title>
    </head>
    <body>
        <h1>Produtos</h1>

        <label for="lblNome">Nome:</label>
        <input type="text" name="nome" value="<?php echo e($produto->nome); ?>">
        <br><br>
        <label for="lblValor">Valor:</label>
        <input type="text" name="valor" value="<?php echo e($produto->valor); ?>">
        <br><br>
        <label for="lblQuantidade">lblQuantidade:</label>
        <input type="text" name="estoque" value="<?php echo e($produto->estoque); ?>">
        <br><br>
    </body>
</html><?php /**PATH C:\xampp\htdocs\biblioteca_laravel\resources\views/listar.blade.php ENDPATH**/ ?>